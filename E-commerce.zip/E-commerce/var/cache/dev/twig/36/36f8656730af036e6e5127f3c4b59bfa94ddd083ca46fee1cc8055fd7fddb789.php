<?php

/* ::includes/col-left.html.twig */
class __TwigTemplate_997d3eb8e6a6e4264ccc481b80584e13b7a2ffba4fbe72e2bb09b3a1d52806b9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2445990f4aa12b5e4ff155fb0a8e5c7231adc6b7ef07a9383c1e6d4339528baa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2445990f4aa12b5e4ff155fb0a8e5c7231adc6b7ef07a9383c1e6d4339528baa->enter($__internal_2445990f4aa12b5e4ff155fb0a8e5c7231adc6b7ef07a9383c1e6d4339528baa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::includes/col-left.html.twig"));

        $__internal_0cff6164cb5a19eebef18ae9dd0ca3ee869155aea8a19c084e9056ae87bc9d18 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0cff6164cb5a19eebef18ae9dd0ca3ee869155aea8a19c084e9056ae87bc9d18->enter($__internal_0cff6164cb5a19eebef18ae9dd0ca3ee869155aea8a19c084e9056ae87bc9d18_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::includes/col-left.html.twig"));

        // line 2
        echo "<div class=\"span3\">
    <div class=\"well\">
        <div class=\"dropdown\">
            <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">
                <i class=\"icon-shopping-cart\"></i>
                3 item - 54,27 €
                <b class=\"caret\"></b></a>
            </a>
            <div class=\"dropdown-menu well\" role=\"menu\" aria-labelledby=\"dLabel\">
                <p>Item x 1 <span class=\"pull-right\">18,09 €</span></p>
                <p>Item x 1 <span class=\"pull-right\">18,09 €</span></p>
                <p>Item x 1 <span class=\"pull-right\">18,09 €</span></p>
                <a href=\"panier.php\" class=\"btn btn-primary\">Mon Panier</a>
            </div>
        </div>
    </div>

    <div class=\"well\">
        <ul class=\"nav nav-list\">
            <li>
                <a href=\"";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_login");
        echo "\">Se connecter</a>
            </li>
            <li>
                <a href=\"";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_registration_register");
        echo "\">S'inscrire</a>
            </li>
        </ul>
    </div>
    
    <div class=\"well\">
        <ul class=\"nav nav-list\">
            <li class=\"nav-header\">Nos produits</li>
            <li class=\"active\">
                <a href=\"index.php\">Légumes</a>
            </li>
            <li>
                <a href=\"index.php\">Fruits</a>
            </li>
        </ul>
    </div>
</div>";
        
        $__internal_2445990f4aa12b5e4ff155fb0a8e5c7231adc6b7ef07a9383c1e6d4339528baa->leave($__internal_2445990f4aa12b5e4ff155fb0a8e5c7231adc6b7ef07a9383c1e6d4339528baa_prof);

        
        $__internal_0cff6164cb5a19eebef18ae9dd0ca3ee869155aea8a19c084e9056ae87bc9d18->leave($__internal_0cff6164cb5a19eebef18ae9dd0ca3ee869155aea8a19c084e9056ae87bc9d18_prof);

    }

    public function getTemplateName()
    {
        return "::includes/col-left.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  53 => 25,  47 => 22,  25 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# <!DOCTYPE html> #}
<div class=\"span3\">
    <div class=\"well\">
        <div class=\"dropdown\">
            <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">
                <i class=\"icon-shopping-cart\"></i>
                3 item - 54,27 €
                <b class=\"caret\"></b></a>
            </a>
            <div class=\"dropdown-menu well\" role=\"menu\" aria-labelledby=\"dLabel\">
                <p>Item x 1 <span class=\"pull-right\">18,09 €</span></p>
                <p>Item x 1 <span class=\"pull-right\">18,09 €</span></p>
                <p>Item x 1 <span class=\"pull-right\">18,09 €</span></p>
                <a href=\"panier.php\" class=\"btn btn-primary\">Mon Panier</a>
            </div>
        </div>
    </div>

    <div class=\"well\">
        <ul class=\"nav nav-list\">
            <li>
                <a href=\"{{ path('fos_user_security_login')}}\">Se connecter</a>
            </li>
            <li>
                <a href=\"{{ path('fos_user_registration_register')}}\">S'inscrire</a>
            </li>
        </ul>
    </div>
    
    <div class=\"well\">
        <ul class=\"nav nav-list\">
            <li class=\"nav-header\">Nos produits</li>
            <li class=\"active\">
                <a href=\"index.php\">Légumes</a>
            </li>
            <li>
                <a href=\"index.php\">Fruits</a>
            </li>
        </ul>
    </div>
</div>", "::includes/col-left.html.twig", "/Applications/MAMP/htdocs/E-commerce/app/Resources/views/includes/col-left.html.twig");
    }
}
