<?php

/* ::layout.html.twig */
class __TwigTemplate_e1f7f87ec41b48af8fed1342f5b3c528629f552ceb88412bb55db66d74a240ad extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascript' => array($this, 'block_javascript'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_993517d977733a4e7b4aefaac1d2dd9f40714cafebaaa331f8822788539a87a4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_993517d977733a4e7b4aefaac1d2dd9f40714cafebaaa331f8822788539a87a4->enter($__internal_993517d977733a4e7b4aefaac1d2dd9f40714cafebaaa331f8822788539a87a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::layout.html.twig"));

        $__internal_f8dc50bc12b57cf5909240aee00e75a7375ddda6552dcaafe06f1597e50df8b3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f8dc50bc12b57cf5909240aee00e75a7375ddda6552dcaafe06f1597e50df8b3->enter($__internal_f8dc50bc12b57cf5909240aee00e75a7375ddda6552dcaafe06f1597e50df8b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
        <link rel=\"stylesheet\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap.css"), "html", null, true);
        echo "\" />
        <link rel=\"stylesheet\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-responsive.css"), "html", null, true);
        echo "\" />
        <link rel=\"stylesheet\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\" />
        <link rel=\"stylesheet\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/font-awesome.css"), "html", null, true);
        echo "\" />
    </head>
    <body>
        <div class=\"navbar navbar-inverse navbar-fixed-top\">
            <div class=\"navbar-inner\">
                <div class=\"container\">
                    <button class=\"btn btn-navbar\" data-target=\".nav-collapse\" data-toggle=\"collapse\" type=\"button\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                    <a class=\"brand\" href=\"";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("ecommerce_home");
        echo "\">RudolpHarryCommerceOnLine</a>
                    <div class=\"nav-collapse collapse\">
                        <form class=\"navbar-form form-search pull-right\">
                            <input id=\"Search\" name=\"Search\" type=\"text\" class=\"input-medium search-query\">
                            <button type=\"submit\" class=\"btn\">Rechercher</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        ";
        // line 32
        $this->displayBlock('body', $context, $blocks);
        // line 34
        echo "
            <hr />

            <footer id=\"footer\" class=\"vspace20\">
                <div class=\"container\">
                    <div class=\"row\">
                        <div class=\"span4 offset1\">
                            <h4>Informations</h4>
                            <ul class=\"nav nav-stacked\">
                                <li><a href=\"";
        // line 43
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pages_homepage", array("id" => 1));
        echo "\">CGV</a>
                                <li><a href=\"";
        // line 44
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pages_homepage", array("id" => 2));
        echo "\">Mentions légales</a>
                            </ul>
                        </div> 

                        <div class=\"span4\">
                            <h4>Notre entrepôt</h4>
                            <p><i class=\"icon-map-marker\"></i>&nbsp;Paris 75 018 - 1 rue pajol</p>
                        </div>

                        <div class=\"span2\">
                            <h4>Nous contacter</h4>
                            <p><i class=\"icon-phone\"></i>&nbsp;Tel: 07 83 36 33 49</p>
                            <p><i class=\"icon-print\"></i>&nbsp;Fax: 06 58 49 79 38</p>
                        </div>
                    </div>

                    <div class=\"row\">
                        <div class=\"span4\">
                            <p>&copy; Copyright 2017 - RudolpHarry</p>
                        </div>
                    </div>
                </div>
            </footer>   
</body>
</html>
        ";
        // line 69
        $this->displayBlock('javascript', $context, $blocks);
        // line 75
        echo "    </body>
</html>
";
        
        $__internal_993517d977733a4e7b4aefaac1d2dd9f40714cafebaaa331f8822788539a87a4->leave($__internal_993517d977733a4e7b4aefaac1d2dd9f40714cafebaaa331f8822788539a87a4_prof);

        
        $__internal_f8dc50bc12b57cf5909240aee00e75a7375ddda6552dcaafe06f1597e50df8b3->leave($__internal_f8dc50bc12b57cf5909240aee00e75a7375ddda6552dcaafe06f1597e50df8b3_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_ad281d94605b60094fc4308f5595ee8767a668ea757e7a92c0798b409b2469dc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ad281d94605b60094fc4308f5595ee8767a668ea757e7a92c0798b409b2469dc->enter($__internal_ad281d94605b60094fc4308f5595ee8767a668ea757e7a92c0798b409b2469dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_358083b5dd62fbb03059eaa9f565670b10a6f558114fce3dde4f13f8000f33e8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_358083b5dd62fbb03059eaa9f565670b10a6f558114fce3dde4f13f8000f33e8->enter($__internal_358083b5dd62fbb03059eaa9f565670b10a6f558114fce3dde4f13f8000f33e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Bienvenue !";
        
        $__internal_358083b5dd62fbb03059eaa9f565670b10a6f558114fce3dde4f13f8000f33e8->leave($__internal_358083b5dd62fbb03059eaa9f565670b10a6f558114fce3dde4f13f8000f33e8_prof);

        
        $__internal_ad281d94605b60094fc4308f5595ee8767a668ea757e7a92c0798b409b2469dc->leave($__internal_ad281d94605b60094fc4308f5595ee8767a668ea757e7a92c0798b409b2469dc_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_1a49610ba20727827ab76916f2b1b5a7600343641293dc6c57f39fea7cb8891c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1a49610ba20727827ab76916f2b1b5a7600343641293dc6c57f39fea7cb8891c->enter($__internal_1a49610ba20727827ab76916f2b1b5a7600343641293dc6c57f39fea7cb8891c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_3b85b2d7096c1b250e846b4c7be5649d2419958e92f6ac141e9b03068355acc6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3b85b2d7096c1b250e846b4c7be5649d2419958e92f6ac141e9b03068355acc6->enter($__internal_3b85b2d7096c1b250e846b4c7be5649d2419958e92f6ac141e9b03068355acc6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_3b85b2d7096c1b250e846b4c7be5649d2419958e92f6ac141e9b03068355acc6->leave($__internal_3b85b2d7096c1b250e846b4c7be5649d2419958e92f6ac141e9b03068355acc6_prof);

        
        $__internal_1a49610ba20727827ab76916f2b1b5a7600343641293dc6c57f39fea7cb8891c->leave($__internal_1a49610ba20727827ab76916f2b1b5a7600343641293dc6c57f39fea7cb8891c_prof);

    }

    // line 32
    public function block_body($context, array $blocks = array())
    {
        $__internal_0c49a42e0cdf44ade6a09423869c438e9cba99b9f1d30aba706986acae0d84eb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0c49a42e0cdf44ade6a09423869c438e9cba99b9f1d30aba706986acae0d84eb->enter($__internal_0c49a42e0cdf44ade6a09423869c438e9cba99b9f1d30aba706986acae0d84eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_73e77bee15cbe2364577913b5b26b1b71fac6f459455b7ebfe2a6a78268f1597 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_73e77bee15cbe2364577913b5b26b1b71fac6f459455b7ebfe2a6a78268f1597->enter($__internal_73e77bee15cbe2364577913b5b26b1b71fac6f459455b7ebfe2a6a78268f1597_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 33
        echo "        ";
        
        $__internal_73e77bee15cbe2364577913b5b26b1b71fac6f459455b7ebfe2a6a78268f1597->leave($__internal_73e77bee15cbe2364577913b5b26b1b71fac6f459455b7ebfe2a6a78268f1597_prof);

        
        $__internal_0c49a42e0cdf44ade6a09423869c438e9cba99b9f1d30aba706986acae0d84eb->leave($__internal_0c49a42e0cdf44ade6a09423869c438e9cba99b9f1d30aba706986acae0d84eb_prof);

    }

    // line 69
    public function block_javascript($context, array $blocks = array())
    {
        $__internal_40796ec1941fdc381fad3178afbcf1467345b16e88a97e4bb64cda9a8c9fb5f1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_40796ec1941fdc381fad3178afbcf1467345b16e88a97e4bb64cda9a8c9fb5f1->enter($__internal_40796ec1941fdc381fad3178afbcf1467345b16e88a97e4bb64cda9a8c9fb5f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascript"));

        $__internal_bfa2c0ca2b5626ef994c33b36e67b24ee62682d8a1391dc69739002bbfe21c6d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bfa2c0ca2b5626ef994c33b36e67b24ee62682d8a1391dc69739002bbfe21c6d->enter($__internal_bfa2c0ca2b5626ef994c33b36e67b24ee62682d8a1391dc69739002bbfe21c6d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascript"));

        // line 70
        echo "        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
        <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>
        <script src=\"";
        // line 72
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery-1.10.0.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 73
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap.js"), "html", null, true);
        echo "\"></script>
        ";
        
        $__internal_bfa2c0ca2b5626ef994c33b36e67b24ee62682d8a1391dc69739002bbfe21c6d->leave($__internal_bfa2c0ca2b5626ef994c33b36e67b24ee62682d8a1391dc69739002bbfe21c6d_prof);

        
        $__internal_40796ec1941fdc381fad3178afbcf1467345b16e88a97e4bb64cda9a8c9fb5f1->leave($__internal_40796ec1941fdc381fad3178afbcf1467345b16e88a97e4bb64cda9a8c9fb5f1_prof);

    }

    public function getTemplateName()
    {
        return "::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  215 => 73,  211 => 72,  207 => 70,  198 => 69,  188 => 33,  179 => 32,  162 => 6,  144 => 5,  132 => 75,  130 => 69,  102 => 44,  98 => 43,  87 => 34,  85 => 32,  72 => 22,  58 => 11,  54 => 10,  50 => 9,  46 => 8,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Bienvenue !{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
        <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap.css') }}\" />
        <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-responsive.css') }}\" />
        <link rel=\"stylesheet\" href=\"{{ asset('css/style.css')}}\" />
        <link rel=\"stylesheet\" href=\"{{ asset('css/font-awesome.css') }}\" />
    </head>
    <body>
        <div class=\"navbar navbar-inverse navbar-fixed-top\">
            <div class=\"navbar-inner\">
                <div class=\"container\">
                    <button class=\"btn btn-navbar\" data-target=\".nav-collapse\" data-toggle=\"collapse\" type=\"button\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                    <a class=\"brand\" href=\"{{ path('ecommerce_home') }}\">RudolpHarryCommerceOnLine</a>
                    <div class=\"nav-collapse collapse\">
                        <form class=\"navbar-form form-search pull-right\">
                            <input id=\"Search\" name=\"Search\" type=\"text\" class=\"input-medium search-query\">
                            <button type=\"submit\" class=\"btn\">Rechercher</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        {% block body %}
        {% endblock %}

            <hr />

            <footer id=\"footer\" class=\"vspace20\">
                <div class=\"container\">
                    <div class=\"row\">
                        <div class=\"span4 offset1\">
                            <h4>Informations</h4>
                            <ul class=\"nav nav-stacked\">
                                <li><a href=\"{{ path('pages_homepage', {'id': 1 }) }}\">CGV</a>
                                <li><a href=\"{{ path('pages_homepage', {'id': 2 }) }}\">Mentions légales</a>
                            </ul>
                        </div> 

                        <div class=\"span4\">
                            <h4>Notre entrepôt</h4>
                            <p><i class=\"icon-map-marker\"></i>&nbsp;Paris 75 018 - 1 rue pajol</p>
                        </div>

                        <div class=\"span2\">
                            <h4>Nous contacter</h4>
                            <p><i class=\"icon-phone\"></i>&nbsp;Tel: 07 83 36 33 49</p>
                            <p><i class=\"icon-print\"></i>&nbsp;Fax: 06 58 49 79 38</p>
                        </div>
                    </div>

                    <div class=\"row\">
                        <div class=\"span4\">
                            <p>&copy; Copyright 2017 - RudolpHarry</p>
                        </div>
                    </div>
                </div>
            </footer>   
</body>
</html>
        {% block javascript %}
        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
        <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>
        <script src=\"{{ asset('js/jquery-1.10.0.min.js') }}\"></script>
        <script src=\"{{ asset('js/bootstrap.js') }}\"></script>
        {% endblock %}
    </body>
</html>
", "::layout.html.twig", "/Applications/MAMP/htdocs/E-commerce/app/Resources/views/layout.html.twig");
    }
}
