<?php

/* EcommerceBundle:Front:index.html.twig */
class __TwigTemplate_44c3de63a83d39739af46e084d1b675f890b48de9623ba7849c1625d1aee551a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("::layout.html.twig", "EcommerceBundle:Front:index.html.twig", 2);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_62b9f73b5cfcd2f8158f6139c53a0021c814b9723fb8a847641ee33bdf5e9fdd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_62b9f73b5cfcd2f8158f6139c53a0021c814b9723fb8a847641ee33bdf5e9fdd->enter($__internal_62b9f73b5cfcd2f8158f6139c53a0021c814b9723fb8a847641ee33bdf5e9fdd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EcommerceBundle:Front:index.html.twig"));

        $__internal_51eb3a3850313128081a298b02ff01ca06601e9ee3b0c25a3341fbcf395b5732 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_51eb3a3850313128081a298b02ff01ca06601e9ee3b0c25a3341fbcf395b5732->enter($__internal_51eb3a3850313128081a298b02ff01ca06601e9ee3b0c25a3341fbcf395b5732_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EcommerceBundle:Front:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_62b9f73b5cfcd2f8158f6139c53a0021c814b9723fb8a847641ee33bdf5e9fdd->leave($__internal_62b9f73b5cfcd2f8158f6139c53a0021c814b9723fb8a847641ee33bdf5e9fdd_prof);

        
        $__internal_51eb3a3850313128081a298b02ff01ca06601e9ee3b0c25a3341fbcf395b5732->leave($__internal_51eb3a3850313128081a298b02ff01ca06601e9ee3b0c25a3341fbcf395b5732_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_616662c1c640e6738e9831e9096e77c1354bacd8ebf9996e6fc9f90bd5bd86b4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_616662c1c640e6738e9831e9096e77c1354bacd8ebf9996e6fc9f90bd5bd86b4->enter($__internal_616662c1c640e6738e9831e9096e77c1354bacd8ebf9996e6fc9f90bd5bd86b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_d2ce380e77d3769238eab94aaba67e8421226ad5caf2c147ed5c904aa3632921 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d2ce380e77d3769238eab94aaba67e8421226ad5caf2c147ed5c904aa3632921->enter($__internal_d2ce380e77d3769238eab94aaba67e8421226ad5caf2c147ed5c904aa3632921_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "<div class=\"container\">
    <div class=\"row\">

    ";
        // line 8
        $this->loadTemplate("::includes/col-left.html.twig", "EcommerceBundle:Front:index.html.twig", 8)->display($context);
        // line 9
        echo "        <div class=\"span9\">

            <ul class=\"thumbnails\">
                ";
        // line 12
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range(0, 10));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 13
            echo "                <li class=\"span3\">
                    <div class=\"thumbnail\">
                        <img src=\"";
            // line 15
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("img/taupe.jpg"), "html", null, true);
            echo "\" alt=\"MaTaupe\" width=\"300\" height=\"300\">
                        <div class=\"caption\">
                            <h4>Thumbnail label</h4>
                            <p>100,00 €</p>
                            <a class=\"btn btn-primary\" href=\"";
            // line 19
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("ecommerce_produits");
            echo "\">Plus d'infos</a>
                            <a class=\"btn btn-success\" href=\"";
            // line 20
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("ecommerce_panier");
            echo "\">Ajouter au panier</a>
                        </div>
                    </div>
                </li>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 25
        echo "            </ul>

            <div class=\"pagination\">
                <ul>
                    <li class=\"disabled\"><span>Précédent</span></li>
                    <li class=\"disabled\"><span>1</span></li>
                    <li><a href=\"#\">2</a></li>
                    <li><a href=\"#\">3</a></li>
                    <li><a href=\"#\">4</a></li>
                    <li><a href=\"#\">5</a></li>
                    <li><a href=\"#\">Suivant</a></li>
                </ul>
            </div>

        </div>
    </div>
</div>
";
        
        $__internal_d2ce380e77d3769238eab94aaba67e8421226ad5caf2c147ed5c904aa3632921->leave($__internal_d2ce380e77d3769238eab94aaba67e8421226ad5caf2c147ed5c904aa3632921_prof);

        
        $__internal_616662c1c640e6738e9831e9096e77c1354bacd8ebf9996e6fc9f90bd5bd86b4->leave($__internal_616662c1c640e6738e9831e9096e77c1354bacd8ebf9996e6fc9f90bd5bd86b4_prof);

    }

    public function getTemplateName()
    {
        return "EcommerceBundle:Front:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  91 => 25,  80 => 20,  76 => 19,  69 => 15,  65 => 13,  61 => 12,  56 => 9,  54 => 8,  49 => 5,  40 => 4,  11 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# <!DOCTYPE html> #}
{% extends \"::layout.html.twig\" %}

{% block body %}
<div class=\"container\">
    <div class=\"row\">

    {% include '::includes/col-left.html.twig' %}
        <div class=\"span9\">

            <ul class=\"thumbnails\">
                {% for i in 0..10 %}
                <li class=\"span3\">
                    <div class=\"thumbnail\">
                        <img src=\"{{ asset('img/taupe.jpg') }}\" alt=\"MaTaupe\" width=\"300\" height=\"300\">
                        <div class=\"caption\">
                            <h4>Thumbnail label</h4>
                            <p>100,00 €</p>
                            <a class=\"btn btn-primary\" href=\"{{ path('ecommerce_produits') }}\">Plus d'infos</a>
                            <a class=\"btn btn-success\" href=\"{{ path('ecommerce_panier') }}\">Ajouter au panier</a>
                        </div>
                    </div>
                </li>
                {% endfor %}
            </ul>

            <div class=\"pagination\">
                <ul>
                    <li class=\"disabled\"><span>Précédent</span></li>
                    <li class=\"disabled\"><span>1</span></li>
                    <li><a href=\"#\">2</a></li>
                    <li><a href=\"#\">3</a></li>
                    <li><a href=\"#\">4</a></li>
                    <li><a href=\"#\">5</a></li>
                    <li><a href=\"#\">Suivant</a></li>
                </ul>
            </div>

        </div>
    </div>
</div>
{% endblock %}", "EcommerceBundle:Front:index.html.twig", "/Applications/MAMP/htdocs/E-commerce/src/Ecommerce/EcommerceBundle/Resources/views/Front/index.html.twig");
    }
}
