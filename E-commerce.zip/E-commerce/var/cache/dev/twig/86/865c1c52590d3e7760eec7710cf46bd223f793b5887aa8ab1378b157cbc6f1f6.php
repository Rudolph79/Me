<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_3af4a99c1cb655a4825f0a6e01551d674b52d52b622e47d73e3845cb1496152a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_af308183e59a712b9ff0e29aa0459c31c4fb5bedd52428100a0cc37222dea10b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_af308183e59a712b9ff0e29aa0459c31c4fb5bedd52428100a0cc37222dea10b->enter($__internal_af308183e59a712b9ff0e29aa0459c31c4fb5bedd52428100a0cc37222dea10b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_571388172c916624d5e34e3a70adcd1ceb690b99c160966df0054529d7c5a75e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_571388172c916624d5e34e3a70adcd1ceb690b99c160966df0054529d7c5a75e->enter($__internal_571388172c916624d5e34e3a70adcd1ceb690b99c160966df0054529d7c5a75e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_af308183e59a712b9ff0e29aa0459c31c4fb5bedd52428100a0cc37222dea10b->leave($__internal_af308183e59a712b9ff0e29aa0459c31c4fb5bedd52428100a0cc37222dea10b_prof);

        
        $__internal_571388172c916624d5e34e3a70adcd1ceb690b99c160966df0054529d7c5a75e->leave($__internal_571388172c916624d5e34e3a70adcd1ceb690b99c160966df0054529d7c5a75e_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_c86986bcadb5b73b374b1eef7d7813142f869965fa3cb5224bd53e32e08fd900 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c86986bcadb5b73b374b1eef7d7813142f869965fa3cb5224bd53e32e08fd900->enter($__internal_c86986bcadb5b73b374b1eef7d7813142f869965fa3cb5224bd53e32e08fd900_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_c743b55ed8eef9b12e3590488a9263b7ea1dd454f020d2312ac87b525158d5a0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c743b55ed8eef9b12e3590488a9263b7ea1dd454f020d2312ac87b525158d5a0->enter($__internal_c743b55ed8eef9b12e3590488a9263b7ea1dd454f020d2312ac87b525158d5a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_c743b55ed8eef9b12e3590488a9263b7ea1dd454f020d2312ac87b525158d5a0->leave($__internal_c743b55ed8eef9b12e3590488a9263b7ea1dd454f020d2312ac87b525158d5a0_prof);

        
        $__internal_c86986bcadb5b73b374b1eef7d7813142f869965fa3cb5224bd53e32e08fd900->leave($__internal_c86986bcadb5b73b374b1eef7d7813142f869965fa3cb5224bd53e32e08fd900_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_e1477175640af1e9f9a7ed024e41ae6f3348bb825e00601b133791bb4cfd5157 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e1477175640af1e9f9a7ed024e41ae6f3348bb825e00601b133791bb4cfd5157->enter($__internal_e1477175640af1e9f9a7ed024e41ae6f3348bb825e00601b133791bb4cfd5157_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_cf151f0fd2a02d94d3e89010d8f59629c7fd0efe55667096c082aa6d00575932 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cf151f0fd2a02d94d3e89010d8f59629c7fd0efe55667096c082aa6d00575932->enter($__internal_cf151f0fd2a02d94d3e89010d8f59629c7fd0efe55667096c082aa6d00575932_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_cf151f0fd2a02d94d3e89010d8f59629c7fd0efe55667096c082aa6d00575932->leave($__internal_cf151f0fd2a02d94d3e89010d8f59629c7fd0efe55667096c082aa6d00575932_prof);

        
        $__internal_e1477175640af1e9f9a7ed024e41ae6f3348bb825e00601b133791bb4cfd5157->leave($__internal_e1477175640af1e9f9a7ed024e41ae6f3348bb825e00601b133791bb4cfd5157_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_8404f054e42535bf4f4a380e8ec52080ebb469faee55e1f2e4d8f66c56f8f8f7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8404f054e42535bf4f4a380e8ec52080ebb469faee55e1f2e4d8f66c56f8f8f7->enter($__internal_8404f054e42535bf4f4a380e8ec52080ebb469faee55e1f2e4d8f66c56f8f8f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_67cd384694e2d6e741d4edf94ff93c1ecf32ee11fce12d8b987d2496d0e509e9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_67cd384694e2d6e741d4edf94ff93c1ecf32ee11fce12d8b987d2496d0e509e9->enter($__internal_67cd384694e2d6e741d4edf94ff93c1ecf32ee11fce12d8b987d2496d0e509e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_67cd384694e2d6e741d4edf94ff93c1ecf32ee11fce12d8b987d2496d0e509e9->leave($__internal_67cd384694e2d6e741d4edf94ff93c1ecf32ee11fce12d8b987d2496d0e509e9_prof);

        
        $__internal_8404f054e42535bf4f4a380e8ec52080ebb469faee55e1f2e4d8f66c56f8f8f7->leave($__internal_8404f054e42535bf4f4a380e8ec52080ebb469faee55e1f2e4d8f66c56f8f8f7_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/Applications/MAMP/htdocs/E-commerce/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
