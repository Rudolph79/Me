<?php

namespace Ecommerce\EcommerceBundle\DataFixtures\ORM;

use Doctrine\Common\DataFixtures\OrderedFixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;
use Doctrine\Common\DataFixtures\AbstractFixture;
use Ecommerce\EcommerceBundle\Entity\Media;


class LoadMediaData extends AbstractFixture implements OrderedFixtureInterface	
{
	public function load(ObjectManager $manager)
	{
		$media1 = new Media();
		$media1->setPath('https://www.google.fr/search?biw=1206&bih=635&tbm=isch&q=pomme+rouge&sa=X&ved=0ahUKEwi74dmF8prYAhXjCMAKHeUeBZIQhyYIJg');
		$media1->setAlt('Pomme');
		$manager->persist($media1);

		$media2 = new Media();
		$media2->setPath('https://www.google.fr/search?biw=1206&bih=635&tbm=isch&q=pomme+de+terre+cuite&sa=X&ved=0ahUKEwjt6-GR8prYAhVlOMAKHTjqB48QhyYIMg');
		$media2->setAlt('Pomme de terre');
		$manager->persist($media2);

		$media3 = new Media();
		$media3->setPath('hhttps://www.google.fr/search?biw=1206&bih=635&tbm=isch&q=ananas+fruit+png&sa=X&ved=0ahUKEwjQtpTi8prYAhVoIsAKHSTYBkgQhyYIIw');
		$media3->setAlt('Ananas');
		$manager->persist($media3);

		$media4 = new Media();
		$media4->setPath('https://www.google.fr/search?biw=1206&bih=635&tbm=isch&q=banane+fruit&sa=X&ved=0ahUKEwjQtpTi8prYAhVoIsAKHSTYBkgQhyYIJg');
		$media4->setAlt('Banane');
		$manager->persist($media4);

		$media5 = new Media();
		$media5->setPath('https://www.google.fr/search?biw=1206&bih=635&tbm=isch&q=orange+fruit+png&sa=X&ved=0ahUKEwjp7-D28prYAhVlBsAKHWtbADoQhyYIIw');
		$media5->setAlt('Orange');
		$manager->persist($media5);

		$media6 = new Media();
		$media6->setPath('https://www.google.fr/search?biw=1206&bih=635&tbm=isch&q=avocat+fruit+en+arabe&sa=X&ved=0ahUKEwi6tbaC85rYAhUIBsAKHYBEC9oQhyYILA');
		$media6->setAlt('Avocat');
		$manager->persist($media6);

		$media7 = new Media();
		$media7->setPath('https://www.google.fr/search?biw=1206&bih=635&tbm=isch&q=pomme+cyth%C3%A8re+arbre&sa=X&ved=0ahUKEwjqxo-n85rYAhXpCMAKHeVCDj4QhyYIIw');
		$media7->setAlt('Pomme citerne');
		$manager->persist($media7);

		$media8 = new Media();
		$media8->setPath('https://www.google.fr/search?biw=1206&bih=635&tbm=isch&q=goyave+fruit&sa=X&ved=0ahUKEwid2sGz85rYAhVpJsAKHbqGCVoQhyYIMg');
		$media8->setAlt('Goyave');
		$manager->persist($media8);



		


		$manager->flush();

		$this->addReference('media1', $media1);
		$this->addReference('media2', $media2);
		$this->addReference('media3', $media3);
		$this->addReference('media4', $media4);
		$this->addReference('media5', $media5);
		$this->addReference('media6', $media6);
		$this->addReference('media7', $media7);
		$this->addReference('media8', $media8);
		
	}

	public function getOrder()
	{
		return 1;
	}

}