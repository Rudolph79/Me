<?php

namespace Ecommerce\EcommerceBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Ecommerce\EcommerceBundle\Entity\Produits;


class TestController extends Controller
{
    public function testAction()
    {
        /*$em = $this->getDoctrine()->getManager();

        $produit = new Produits();
        $produit->setCategorie('Légume');
        $produit->setDescription('La tomate est un bon légume');
        $produit->setDisponible('1');
        $produit->setImage('http://www.azura-group.com/wp-content/themes/twentytwelve/images/images/tomates.png');
        $produit->setNom('Tomate');
        $produit->setPrix('0.35');
        $produit->setTva('19.6');

        $em->persist($produit);

        $produit2 = new Produits();
        $produit2->setCategorie('Légume');
        $produit2->setDescription('Une bonne pomme de terre');
        $produit2->setDisponible('1');
        $produit2->setImage('https://www.comptoirdesjardins.fr/1051-thickbox_default/plants-de-pomme-de-terre-bio-apollo-3-kg.jpg');
        $produit2->setNom('Pomme de terre');
        $produit2->setPrix('0.67');
        $produit2->setTva('19.6');

        $em->persist($produit2);

        $em->flush();*/

        $em = $this->getDoctrine()->getManager();
        $produits = $em->getRepository('EcommerceBundle:Produits')->findAll();


        return $this->render('EcommerceBundle:Test:test.html.twig', array('produits' => $produits));
    }
}
