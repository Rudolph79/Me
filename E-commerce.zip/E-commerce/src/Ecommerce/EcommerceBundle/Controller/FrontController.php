<?php

namespace Ecommerce\EcommerceBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class FrontController extends Controller
{
    public function panierAction()
    {
        return $this->render('EcommerceBundle:Front:panier.html.twig');
    }

    public function produitsAction()
    {
        return $this->render('EcommerceBundle:Front:produits.html.twig');
    }

    public function indexAction()
    {
    	return $this->render('EcommerceBundle:Front:index.html.twig');
    }

    public function livraisonAction()
    {
    	return $this->render('EcommerceBundle:Front:livraison.html.twig');
    }

    public function validationAction()
    {
    	return $this->render('EcommerceBundle:Front:validation.html.twig');
    }
}
