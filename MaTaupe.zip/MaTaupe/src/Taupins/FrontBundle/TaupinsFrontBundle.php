<?php

namespace Taupins\FrontBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TaupinsFrontBundle extends Bundle
{
}
