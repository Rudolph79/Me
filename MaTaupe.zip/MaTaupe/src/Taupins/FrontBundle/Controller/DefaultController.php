<?php

namespace Taupins\FrontBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class DefaultController extends Controller
{
    public function indexAction()
    {
        return $this->render('TaupinsFrontBundle:Default:index.html.twig');
    }
}
