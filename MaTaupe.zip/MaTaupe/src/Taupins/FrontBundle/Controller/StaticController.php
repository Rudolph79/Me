<?php

namespace Taupins\FrontBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class StaticController extends Controller
{
    public function indexAction()
    {
        return $this->render('TaupinsFrontBundle:Static:index.html.twig');
    }
}
